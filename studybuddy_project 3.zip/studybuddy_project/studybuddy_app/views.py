from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.models import User
from django.db.models import Q
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.core.exceptions import PermissionDenied
from django.http import Http404, HttpResponseForbidden
from django.urls import reverse
from django.core.paginator import Paginator

from .models import Profile, Message, StudySession, Review, Course
from .forms import ProfileAddForm, ReviewForm, CourseAddForm

# ---------------------------------------
# Utility Views
# ---------------------------------------
def custom_404(request, exception):
    """Custom 404 error handler"""
    return render(request, 'studybuddy_app/profile/404.html', status=404)

def custom_500(request):
    """Custom 500 error handler"""
    return render(request, 'studybuddy_app/profile/500.html', status=500)

# ---------------------------------------
# Home Page
# ---------------------------------------
def index(request):
    """Render the home page with featured profiles"""
    try:
        featured_profiles = None
        if request.user.is_authenticated:
            featured_profiles = Profile.objects.exclude(user=request.user).order_by('?')[:3]
        return render(request, 'studybuddy_app/profile/index.html', {
            'featured_profiles': featured_profiles
        })
    except Exception as e:
        messages.error(request, "An error occurred while loading the homepage.")
        return render(request, 'studybuddy_app/profile/index.html')

# ---------------------------------------
# Authentication Views (updated paths)
# ---------------------------------------
def signup(request):
    """Handle user registration"""
    if request.user.is_authenticated:
        messages.info(request, "You're already logged in.")
        return redirect('studybuddy_app:index')
        
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            try:
                user = form.save()
                login(request, user)
                messages.success(request, "Account created successfully! Please create your profile.")
                return redirect('studybuddy_app:profile_add')
            except Exception as e:
                messages.error(request, f"Error creating account: {str(e)}")
        else:
            messages.error(request, "Please correct the errors below.")
    else:
        form = UserCreationForm()
    
    return render(request, 'studybuddy_app/registration/signup.html', {'form': form})

def user_login(request):
    """Handle user login"""
    if request.user.is_authenticated:
        return redirect('studybuddy_app:index')
        
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.success(request, f"Welcome back, {username}!")
                next_url = request.GET.get('next', 'studybuddy_app:index')
                return redirect(next_url)
        messages.error(request, "Invalid username or password.")
    else:
        form = AuthenticationForm()
    
    return render(request, 'studybuddy_app/registration/login.html', {'form': form})

def user_logout(request):
    """Handle user logout"""
    if request.user.is_authenticated:
        logout(request)
        messages.info(request, "You have been logged out.")
    return redirect('studybuddy_app:index')

# ---------------------------------------
# Profile Views
# ---------------------------------------
@login_required
def profile(request, pk):
    """View a specific user profile"""
    try:
        profile = get_object_or_404(Profile, pk=pk)
        reviews = Review.objects.filter(reviewed_user=profile.user).select_related('reviewer')
        can_review = (request.user != profile.user and 
                     not Review.objects.filter(reviewer=request.user, reviewed_user=profile.user).exists())
        
        return render(request, 'studybuddy_app/profile/profile.html', {
            'profile': profile,
            'reviews': reviews,
            'can_review': can_review
        })
    except Exception as e:
        messages.error(request, "Error loading profile.")
        return redirect('studybuddy_app:profile_list')

@login_required
def profile_list(request):
    """List all user profiles with pagination"""
    try:
        profiles = Profile.objects.exclude(user=request.user).select_related('user')
        paginator = Paginator(profiles, 10)  # Show 10 profiles per page
        page_number = request.GET.get('page')
        page_obj = paginator.get_page(page_number)
        return render(request, 'studybuddy_app/profile/profile_list.html', {'page_obj': page_obj})
    except Exception as e:
        messages.error(request, "Error loading profiles.")
        return render(request, 'studybuddy_app/profile/profile_list.html', {'page_obj': None})

@login_required
def profile_add(request):
    """Create a new user profile"""
    if hasattr(request.user, 'profile'):
        return redirect('studybuddy_app:profile', pk=request.user.profile.pk)
    
    if request.method == "POST":
        form = ProfileAddForm(request.POST, request.FILES)
        if form.is_valid():
            try:
                profile = form.save(commit=False)
                profile.user = request.user
                if 'picture' in request.FILES:
                    profile.picture = request.FILES['picture']
                profile.save()
                form.save_m2m()  # Save many-to-many data
                messages.success(request, "Profile created successfully!")
                return redirect('studybuddy_app:profile', pk=profile.pk)
            except Exception as e:
                messages.error(request, f"Error saving profile: {str(e)}")
        else:
            messages.error(request, "Please correct the errors below.")
    else:
        form = ProfileAddForm()
    
    return render(request, 'studybuddy_app/profile/profile_add.html', {'form': form})

# ---------------------------------------
# Course Views
# ---------------------------------------
def course_list(request):
    """List all available courses with pagination"""
    try:
        courses = Course.objects.all().order_by('code')
        paginator = Paginator(courses, 10)  # Show 10 courses per page
        page_number = request.GET.get('page')
        page_obj = paginator.get_page(page_number)
        return render(request, 'studybuddy_app/profile/course_list.html', {'page_obj': page_obj})
    except Exception as e:
        messages.error(request, "Error loading courses.")
        return render(request, 'studybuddy_app/profile/course_list.html', {'page_obj': None})

def course_detail(request, pk):
    """View details of a specific course"""
    try:
        course = get_object_or_404(Course, pk=pk)
        enrolled_profiles = Profile.objects.filter(courses=course).exclude(user=request.user)
        return render(request, 'studybuddy_app/profile/course_detail.html', {
            'course': course,
            'enrolled_profiles': enrolled_profiles
        })
    except Exception as e:
        messages.error(request, "Error loading course details.")
        return redirect('studybuddy_app:course_list')

@login_required
def course_add(request):
    """Add a new course (admin only)"""
    if not request.user.is_superuser:
        raise PermissionDenied("Only administrators can add courses.")
        
    if request.method == 'POST':
        form = CourseAddForm(request.POST)
        if form.is_valid():
            try:
                course = form.save()
                messages.success(request, f"Course {course.code} added successfully!")
                return redirect('studybuddy_app:course_detail', pk=course.pk)
            except Exception as e:
                messages.error(request, f"Error saving course: {str(e)}")
        else:
            messages.error(request, "Please correct the errors below.")
    else:
        form = CourseAddForm()
    
    return render(request, 'studybuddy_app/profile/course_add.html', {'form': form})

# ---------------------------------------
# Matching System
# ---------------------------------------
@login_required
def find_matches(request):
    """Find study buddies based on shared courses"""
    if not hasattr(request.user, 'profile'):
        messages.warning(request, "Please create a profile first.")
        return redirect('studybuddy_app:profile_add')
        
    try:
        user_profile = request.user.profile
        matches = Profile.objects.filter(
            courses__in=user_profile.courses.all()
        ).exclude(user=request.user).distinct()
        
        return render(request, 'studybuddy_app/profile/matches.html', {
            'matches': matches,
            'user_courses': user_profile.courses.all()
        })
    except Exception as e:
        messages.error(request, "Error finding matches.")
        return redirect('studybuddy_app:index')

# ---------------------------------------
# Messaging System
# ---------------------------------------
@login_required
def send_message(request, receiver_id):
    """Send a message to another user"""
    receiver = get_object_or_404(User, id=receiver_id)
    
    if request.method == 'POST':
        content = request.POST.get('content', '').strip()
        if content:
            try:
                Message.objects.create(
                    sender=request.user,
                    receiver=receiver,
                    content=content
                )
                messages.success(request, "Message sent successfully!")
                return redirect('studybuddy_app:inbox')
            except Exception as e:
                messages.error(request, "Error sending message.")
        else:
            messages.error(request, "Message cannot be empty.")
    
    return render(request, 'studybuddy_app/profile/send_message.html', {'receiver': receiver})

@login_required
def inbox(request):
    """View received messages with pagination"""
    try:
        messages_received = Message.objects.filter(
            receiver=request.user
        ).select_related('sender').order_by('-timestamp')
        
        paginator = Paginator(messages_received, 10)  # Show 10 messages per page
        page_number = request.GET.get('page')
        page_obj = paginator.get_page(page_number)
        
        return render(request, 'studybuddy_app/profile/inbox.html', {'page_obj': page_obj})
    except Exception as e:
        messages.error(request, "Error loading messages.")
        return render(request, 'studybuddy_app/profile/inbox.html', {'page_obj': None})

# ---------------------------------------
# Review System
# ---------------------------------------
@login_required
def leave_review(request, profile_id):
    """Leave a review for another user"""
    profile = get_object_or_404(Profile, id=profile_id)
    
    if request.user == profile.user:
        messages.error(request, "You cannot review yourself.")
        return redirect('studybuddy_app:profile', pk=profile_id)
        
    if Review.objects.filter(reviewer=request.user, reviewed_user=profile.user).exists():
        messages.error(request, "You have already reviewed this user.")
        return redirect('studybuddy_app:profile', pk=profile_id)
    
    if request.method == 'POST':
        form = ReviewForm(request.POST)
        if form.is_valid():
            try:
                review = form.save(commit=False)
                review.reviewer = request.user
                review.reviewed_user = profile.user
                review.save()
                messages.success(request, "Review submitted successfully!")
                return redirect('studybuddy_app:profile', pk=profile_id)
            except Exception as e:
                messages.error(request, "Error submitting review.")
        else:
            messages.error(request, "Please correct the errors below.")
    else:
        form = ReviewForm()
    
    return render(request, 'studybuddy_app/profile/leave_review.html', {
        'form': form,
        'profile': profile
    })

# ---------------------------------------
# Search Functionality
# ---------------------------------------
def search_buddies(request):
    """Search for study buddies based on various criteria"""
    query = request.GET.get('q', '').strip()
    
    try:
        if query:
            results = Profile.objects.filter(
                Q(courses__name__icontains=query) |
                Q(study_methods__icontains=query) |
                Q(bio__icontains=query) |
                Q(user__username__icontains=query)
            ).exclude(user=request.user).distinct()
            
            paginator = Paginator(results, 10)  # Show 10 results per page
            page_number = request.GET.get('page')
            page_obj = paginator.get_page(page_number)
        else:
            page_obj = None
            messages.info(request, "Please enter a search term.")
        
        return render(request, 'studybuddy_app/profile/search_results.html', {
            'page_obj': page_obj,
            'query': query
        })
    except Exception as e:
        messages.error(request, "Error performing search.")
        return render(request, 'studybuddy_app/profile/search_results.html', {'page_obj': None, 'query': query})

# ---------------------------------------
# Study Calendar
# ---------------------------------------
@login_required
def study_calendar(request):
    """View study sessions calendar"""
    try:
        sessions = StudySession.objects.filter(
            Q(creator=request.user) | 
            Q(participants=request.user)
        ).distinct().order_by('scheduled_time')
        
        return render(request, 'studybuddy_app/profile/calendar.html', {
            'sessions': sessions
        })
    except Exception as e:
        messages.error(request, "Error loading calendar.")
        return render(request, 'studybuddy_app/profile/calendar.html', {'sessions': None})