from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MinValueValidator, MaxValueValidator

class TimestampModel(models.Model):
    """Abstract base model with created_at and updated_at fields"""
    created_at = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    updated_at = models.DateTimeField(auto_now=True, null=True, blank=True)

    class Meta:
        abstract = True

# -------------------------------------
# COURSE
# -------------------------------------
class Course(TimestampModel):
    code = models.CharField(max_length=10, unique=True)
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    credits = models.PositiveSmallIntegerField(default=3)

    class Meta:
        ordering = ['code']

    def __str__(self):
        return f"{self.code} - {self.name}"

# -------------------------------------
# STATUS
# -------------------------------------
class Status(TimestampModel):
    name = models.CharField(max_length=50, unique=True)
    description = models.CharField(max_length=100, blank=True)

    class Meta:
        verbose_name_plural = "statuses"
        ordering = ['name']

    def __str__(self):
        return self.name

# -------------------------------------
# PROFILE
# -------------------------------------
class Profile(TimestampModel):
    user = models.OneToOneField(
        User, 
        on_delete=models.CASCADE, 
        related_name='profile'
    )
    fname = models.CharField("First name", max_length=50)
    lname = models.CharField("Last name", max_length=50)
    email = models.EmailField(unique=True)
    bio = models.TextField(blank=True)
    availability = models.CharField(max_length=100, blank=True)
    courses = models.ManyToManyField(Course, blank=True, related_name='students')
    study_methods = models.CharField(max_length=200, blank=True)
    rating = models.FloatField(
        default=0.0,
        validators=[MinValueValidator(0.0), MaxValueValidator(5.0)]
    )
    status = models.ForeignKey(
        Status, 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True
    )
    picture = models.ImageField(
        upload_to='profile_pics/', 
        blank=True, 
        null=True
    )

    class Meta:
        ordering = ['lname', 'fname']

    def __str__(self):
        return f"{self.fname} {self.lname}"

    def full_name(self):
        return f"{self.fname} {self.lname}"

# -------------------------------------
# STUDY MATCH
# -------------------------------------
class StudyMatch(TimestampModel):
    profile1 = models.ForeignKey(
        Profile, 
        on_delete=models.CASCADE, 
        related_name='matches_initiated'
    )
    profile2 = models.ForeignKey(
        Profile, 
        on_delete=models.CASCADE, 
        related_name='matches_received'
    )
    accepted = models.BooleanField(default=False)

    class Meta:
        unique_together = [['profile1', 'profile2']]
        verbose_name_plural = "study matches"

    def __str__(self):
        return f"{self.profile1} + {self.profile2}"

# -------------------------------------
# MESSAGE
# -------------------------------------
class Message(TimestampModel):
    sender = models.ForeignKey(
        User, 
        related_name='sent_messages', 
        on_delete=models.CASCADE
    )
    receiver = models.ForeignKey(
        User, 
        related_name='received_messages', 
        on_delete=models.CASCADE
    )
    content = models.TextField()
    read = models.BooleanField(default=False)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"From {self.sender.username} to {self.receiver.username}"

# -------------------------------------
# REVIEW
# -------------------------------------
class Review(TimestampModel):
    reviewer = models.ForeignKey(
        User, 
        related_name='given_reviews', 
        on_delete=models.CASCADE
    )
    reviewed_user = models.ForeignKey(
        User, 
        related_name='received_reviews', 
        on_delete=models.CASCADE
    )
    rating = models.IntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(5)]
    )
    comment = models.TextField()

    class Meta:
        unique_together = [['reviewer', 'reviewed_user']]
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.reviewer.username} → {self.reviewed_user.username} ({self.rating}/5)"

# -------------------------------------
# STUDY SESSION
# -------------------------------------
class StudySession(TimestampModel):
    creator = models.ForeignKey(
        User, 
        on_delete=models.CASCADE,
        related_name='created_sessions'
    )
    course = models.ForeignKey(
        Course, 
        on_delete=models.CASCADE,
        related_name='sessions'
    )
    topic = models.CharField(max_length=200)
    scheduled_time = models.DateTimeField()
    location = models.CharField(max_length=200)
    participants = models.ManyToManyField(
        User, 
        related_name='attending_sessions',
        blank=True
    )
    max_participants = models.PositiveSmallIntegerField(
        default=5,
        validators=[MinValueValidator(2), MaxValueValidator(20)]
    )

    class Meta:
        ordering = ['scheduled_time']

    def __str__(self):
        return f"{self.topic} - {self.course.code} @ {self.scheduled_time}"

# -------------------------------------
# STUDY RESOURCE
# -------------------------------------
class StudyResource(TimestampModel):
    uploader = models.ForeignKey(
        User, 
        on_delete=models.CASCADE,
        related_name='uploaded_resources'
    )
    course = models.ForeignKey(
        Course, 
        on_delete=models.CASCADE,
        related_name='resources'
    )
    title = models.CharField(max_length=200)
    file = models.FileField(upload_to='resources/')
    description = models.TextField()
    approved = models.BooleanField(default=False)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return self.title

# -------------------------------------
# NOTIFICATION
# -------------------------------------
class Notification(TimestampModel):
    user = models.ForeignKey(
        User, 
        on_delete=models.CASCADE,
        related_name='notifications'
    )
    message = models.CharField(max_length=255)
    read = models.BooleanField(default=False)
    link = models.URLField()
    notification_type = models.CharField(
        max_length=20,
        choices=[
            ('message', 'New Message'),
            ('match', 'New Match'),
            ('review', 'New Review'),
            ('session', 'Session Reminder'),
        ],
        default='message'
    )

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.notification_type} for {self.user.username}"

# -------------------------------------
# STUDY GOAL
# -------------------------------------
class StudyGoal(TimestampModel):
    user = models.ForeignKey(
        User, 
        on_delete=models.CASCADE,
        related_name='study_goals'
    )
    title = models.CharField(max_length=200)
    description = models.TextField()
    target_date = models.DateField()
    completed = models.BooleanField(default=False)
    priority = models.PositiveSmallIntegerField(
        default=3,
        validators=[MinValueValidator(1), MaxValueValidator(5)]
    )

    class Meta:
        ordering = ['target_date', 'priority']

    def __str__(self):
        return f"{self.title} ({'✓' if self.completed else '✗'})"



