from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    # Admin interface
    path('admin/', admin.site.urls),
    
    # All app URLs
    path('', include('studybuddy_app.urls')),
]

# Serve media files during development
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

# Error handlers (uncomment when ready)
# handler404 = 'studybuddy_app.views.custom_404'
# handler500 = 'studybuddy_app.views.custom_500'