from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.models import User
from django.db.models import Q
from django.urls import reverse
from django.contrib.auth.decorators import login_required

from .models import Profile, Message, StudySession, Review, Course
from .forms import ProfileAddForm, ReviewForm, CourseAddForm

# ---------------------------------------
# Home Page
# ---------------------------------------
def index(request):
    return render(request, 'studybuddy_app/index.html')

# ---------------------------------------
# Authentication
# ---------------------------------------
def signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('index')
    else:
        form = UserCreationForm()
    return render(request, 'registration/signup.html', {'form': form})

def user_login(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            login(request, form.get_user())
            return redirect('index')
    else:
        form = AuthenticationForm()
    return render(request, 'registration/login.html', {'form': form})

def user_logout(request):
    logout(request)
    return redirect('index')

# ---------------------------------------
# Profile
# ---------------------------------------
@login_required
def profile(request, pk):
    user_profile = get_object_or_404(Profile, pk=pk)
    reviews = Review.objects.filter(reviewed_user=user_profile.user)
    return render(request, 'studybuddy_app/profile.html', {
        'profile': user_profile,
        'reviews': reviews
    })

@login_required
def profile_list(request):
    profiles = Profile.objects.exclude(user=request.user)
    return render(request, 'studybuddy_app/profile_list.html', {'profiles': profiles})

@login_required
def profile_add(request):
    try:
        # Check if profile already exists
        existing_profile = Profile.objects.filter(user=request.user).first()
        if existing_profile:
            return redirect('profile', pk=existing_profile.pk)
            
        if request.method == "POST":
            form = ProfileAddForm(request.POST)
            if form.is_valid():
                profile = form.save(commit=False)
                profile.user = request.user
                profile.save()
                form.save_m2m()  # Save many-to-many relationships
                return redirect('profile', pk=profile.pk)
        else:
            form = ProfileAddForm()
            
        return render(request, 'studybuddy_app/profile_add.html', {'form': form})
        
    except Exception as e:
        print(f"Error in profile_add: {str(e)}")
        return redirect('index')

# ---------------------------------------
# Course
# ---------------------------------------
def course_detail(request, pk):
    course = get_object_or_404(Course, pk=pk)
    return render(request, 'studybuddy_app/course_detail.html', {'course': course})

@login_required
def course_add(request):
    if request.method == 'POST':
        form = CourseAddForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('index')
    else:
        form = CourseAddForm()
    return render(request, 'studybuddy_app/course_add.html', {'form': form})

# ---------------------------------------
# Matching
# ---------------------------------------
@login_required
def find_matches(request):
    try:
        user_profile = Profile.objects.get(user=request.user)
        matches = Profile.objects.filter(
            courses__in=user_profile.courses.all()
        ).exclude(user=request.user).distinct()
        
        return render(request, 'studybuddy_app/matches.html', {
            'matches': matches,
            'user_courses': user_profile.courses.all()
        })
        
    except Profile.DoesNotExist:
        return redirect('profile_add')
    except Exception as e:
        print(f"Error in find_matches: {str(e)}")
        return redirect('index')

# ---------------------------------------
# Messaging
# ---------------------------------------
@login_required
def send_message(request, receiver_id):
    receiver = get_object_or_404(User, id=receiver_id)
    if request.method == 'POST':
        content = request.POST.get('content')
        if content:
            Message.objects.create(
                sender=request.user,
                receiver=receiver,
                content=content
            )
        return redirect('inbox')
    return render(request, 'studybuddy_app/send_message.html', {'receiver': receiver})

@login_required
def inbox(request):
    messages = Message.objects.filter(receiver=request.user).order_by('-timestamp')
    return render(request, 'studybuddy_app/inbox.html', {'messages': messages})

# ---------------------------------------
# Reviews
# ---------------------------------------
@login_required
def leave_review(request, profile_id):
    profile = get_object_or_404(Profile, id=profile_id)
    if request.method == 'POST':
        form = ReviewForm(request.POST)
        if form.is_valid():
            review = form.save(commit=False)
            review.reviewer = request.user
            review.reviewed_user = profile.user
            review.save()
            return redirect('profile', pk=profile_id)
    else:
        form = ReviewForm()
    return render(request, 'studybuddy_app/leave_review.html', {'form': form, 'profile': profile})

# ---------------------------------------
# Search
# ---------------------------------------
def search_buddies(request):
    query = request.GET.get('q', '')
    results = Profile.objects.filter(
        Q(courses__name__icontains=query) |
        Q(study_methods__icontains=query) |
        Q(bio__icontains=query)
    ).distinct()
    return render(request, 'studybuddy_app/search_results.html', {'results': results, 'query': query})

# ---------------------------------------
# Calendar
# ---------------------------------------
@login_required
def study_calendar(request):
    sessions = StudySession.objects.filter(
        Q(creator=request.user) | 
        Q(participants=request.user)
    ).distinct()
    return render(request, 'studybuddy_app/calendar.html', {'sessions': sessions})
