from django.db import models
from django.contrib.auth.models import User

# -------------------------------------
# COURSE
# -------------------------------------
class Course(models.Model):
    code = models.CharField(max_length=10)
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)

    def __str__(self):
        return f"{self.code} - {self.name}"

# -------------------------------------
# STATUS (New)
# -------------------------------------
class Status(models.Model):
    name = models.CharField(max_length=50)

    def __str__(self):
        return self.name

# -------------------------------------
# PROFILE
# -------------------------------------
class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    # ... rest of your fields ...
    fname = models.CharField(max_length=50)
    lname = models.CharField(max_length=50)
    email = models.EmailField()
    bio = models.TextField(blank=True)
    availability = models.CharField(max_length=100, blank=True)
    courses = models.ManyToManyField(Course, blank=True)
    study_methods = models.CharField(max_length=200, blank=True)
    rating = models.FloatField(default=0.0)
    status = models.ForeignKey(Status, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return f"{self.fname} {self.lname}"

# -------------------------------------
# STUDY MATCH (New)
# -------------------------------------
class StudyMatch(models.Model):
    profile1 = models.ForeignKey(Profile, on_delete=models.CASCADE, related_name='matches_initiated')
    profile2 = models.ForeignKey(Profile, on_delete=models.CASCADE, related_name='matches_received')
    matched_on = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.profile1} + {self.profile2}"

# -------------------------------------
# MESSAGE
# -------------------------------------
class Message(models.Model):
    sender = models.ForeignKey(User, related_name='sent_messages', on_delete=models.CASCADE)
    receiver = models.ForeignKey(User, related_name='received_messages', on_delete=models.CASCADE)
    content = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"From {self.sender.username} to {self.receiver.username} at {self.timestamp}"

# -------------------------------------
# REVIEW
# -------------------------------------
class Review(models.Model):
    reviewer = models.ForeignKey(User, related_name='given_reviews', on_delete=models.CASCADE)
    reviewed_user = models.ForeignKey(User, related_name='received_reviews', on_delete=models.CASCADE)
    rating = models.IntegerField()
    comment = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.reviewer.username} → {self.reviewed_user.username} ({self.rating}/5)"

# -------------------------------------
# STUDY SESSION
# -------------------------------------
class StudySession(models.Model):
    creator = models.ForeignKey(User, on_delete=models.CASCADE)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    topic = models.CharField(max_length=200)
    scheduled_time = models.DateTimeField()
    location = models.CharField(max_length=200)
    participants = models.ManyToManyField(User, related_name='study_sessions')

    def __str__(self):
        return f"{self.topic} - {self.course.name} @ {self.scheduled_time}"

# -------------------------------------
# STUDY RESOURCE
# -------------------------------------
class StudyResource(models.Model):
    uploader = models.ForeignKey(User, on_delete=models.CASCADE)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    file = models.FileField(upload_to='resources/')
    description = models.TextField()
    upload_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

# -------------------------------------
# NOTIFICATION
# -------------------------------------
class Notification(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    message = models.CharField(max_length=255)
    read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    link = models.URLField()

    def __str__(self):
        return f"To {self.user.username} - {self.message[:20]}"

# -------------------------------------
# STUDY GOAL
# -------------------------------------
class StudyGoal(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    description = models.TextField()
    target_date = models.DateField()
    completed = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.title} ({'Done' if self.completed else 'Pending'})"



