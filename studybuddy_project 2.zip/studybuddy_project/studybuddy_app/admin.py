from django.contrib import admin
from .models import (
    Profile,
    Course,
    Message,
    Review,
    StudySession,
    StudyResource,
    Notification,
    StudyGoal
)
# Remove Status and StudyMatch if they don't exist in models.py

admin.site.register(Profile)
admin.site.register(Course)
admin.site.register(Message)
admin.site.register(Review)
admin.site.register(StudySession)
admin.site.register(StudyResource)
admin.site.register(Notification)
admin.site.register(StudyGoal)


