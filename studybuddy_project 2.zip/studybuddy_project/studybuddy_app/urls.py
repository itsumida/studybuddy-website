from django.urls import path
from . import views

urlpatterns = [
    # Home
    path("", views.index, name="index"),

    # Profiles
    path("profile/<int:pk>/", views.profile, name="profile"),  # Make sure this matches your view function name
    path("profile/add/", views.profile_add, name="profile_add"),
    path("profiles/", views.profile_list, name="profile_list"),
    # Courses
    path("course/<int:pk>/", views.course_detail, name="course_detail"),
    path("course/add/", views.course_add, name="course_add"),

    # Authentication
    path("signup/", views.signup, name="signup"),
    path("login/", views.user_login, name="login"),
    path("logout/", views.user_logout, name="logout"),

    # Messaging
    path("message/send/<int:receiver_id>/", views.send_message, name="send_message"),
    path("inbox/", views.inbox, name="inbox"),

    # Reviews
    path("review/<int:profile_id>/", views.leave_review, name="leave_review"),

    # Study Calendar
    path("calendar/", views.study_calendar, name="study_calendar"),

    # Matching and Search
    path("matches/", views.find_matches, name="find_matches"),
    path("search/", views.search_buddies, name="search_buddies"),
]



