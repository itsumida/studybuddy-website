// Form validation and submission
document.getElementById('signupForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const form = this;
    const submitBtn = document.getElementById('submitBtn');
    const username = document.getElementById('username');
    const email = document.getElementById('email');
    const password1 = document.getElementById('password1');
    const password2 = document.getElementById('password2');
    
    // Reset validation states
    document.querySelectorAll('.form-control').forEach(input => {
        input.classList.remove('is-invalid');
    });
    document.querySelectorAll('.invalid-feedback').forEach(feedback => {
        feedback.style.display = 'none';
    });
    
    let isValid = true;
    
    // Validate username
    if (!username.value.trim() || username.value.length < 3) {
        showFieldError(username, 'Username must be at least 3 characters long');
        isValid = false;
    }
    
    // Validate email
    const emailRegex = /^s\d{7}@bi\.no$/;
    if (!email.value.trim() || !emailRegex.test(email.value)) {
showFieldError(email, 'Only valid BI emails allowed (e.g., s1234567@bi.no)');
isValid = false;
}

    
    // Validate password
    if (!password1.value || password1.value.length < 8) {
        showFieldError(password1, 'Password must be at least 8 characters long');
        isValid = false;
    }
    
    // Validate password confirmation
    if (!password2.value || password1.value !== password2.value) {
        showFieldError(password2, 'Passwords do not match');
        isValid = false;
    }
    
    if (isValid) {
        // Show loading state
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<div class="spinner"></div> Creating Account...';
        
        // Simulate account creation
        setTimeout(() => {
            // For demo: simulate success
            showAlert('success', 'Account created successfully! Welcome to StudyBuddy!');
            
            // Reset form
            form.reset();
            
            // Reset button
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="bi bi-person-plus"></i> Create My Account';
            
            setTimeout(() => {
showAlert('info', 'Redirecting to your dashboard...');

// After showing the message, redirect
setTimeout(() => {
window.location.href = '/'
}, 1000); 
}, 2000);

        }, 2000);
    }
});

function showFieldError(field, message) {
    field.classList.add('is-invalid');
    const feedback = field.nextElementSibling;
    feedback.querySelector('.error-text').textContent = message;
    feedback.style.display = 'flex';
}

function showAlert(type, message) {
    const alertContainer = document.getElementById('alertContainer');
    const alert = document.createElement('div');
    alert.className = `alert alert-${type}`;
    
    const icon = type === 'success' ? 'check-circle-fill' : 
                type === 'danger' ? 'exclamation-triangle-fill' : 'info-circle-fill';
                
    alert.innerHTML = `
        <i class="bi bi-${icon}"></i>
        ${message}
        <button type="button" class="btn-close ms-auto" onclick="this.parentElement.remove()">×</button>
    `;
    
    alertContainer.appendChild(alert);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (alert.parentElement) {
            alert.remove();
        }
    }, 5000);
}

function goToLogin() {
    showAlert('info', 'Redirecting to login page...');
    window.location.href = '/login/';
}

// Add smooth animations to form groups
document.querySelectorAll('.form-control').forEach(input => {
    input.addEventListener('focus', function() {
        this.parentElement.style.transform = 'translateY(-2px)';
        this.parentElement.style.transition = 'transform 0.3s ease';
    });
    
    input.addEventListener('blur', function() {
        this.parentElement.style.transform = 'translateY(0)';
    });
});

// Real-time password matching validation
document.getElementById('password2').addEventListener('input', function() {
    const password1 = document.getElementById('password1').value;
    const password2 = this.value;
    
    if (password2 && password1 !== password2) {
        this.classList.add('is-invalid');
        this.nextElementSibling.style.display = 'flex';
    } else {
        this.classList.remove('is-invalid');
        this.nextElementSibling.style.display = 'none';
    }
});