# studybuddy_app/urls.py (App URLs)
from django.urls import path
from django.contrib.auth.decorators import login_required
from . import views

app_name = 'studybuddy_app'

urlpatterns = [
    # ===========================================
    # MAIN PAGES
    # ===========================================
    path('', views.index, name='index'),
    path('about/', views.more_about, name='more_about'),
    path('about/', views.more_about, name='about'),  # Alternative name for compatibility
    
    # ===========================================
    # AUTHENTICATION
    # ===========================================
    path('signup/', views.signup, name='signup'),
    path('login/', views.user_login, name='login'),
    path('logout/', views.user_logout, name='logout'),
    
    # ===========================================
    # PROFILE MANAGEMENT
    # ===========================================
    path('profile/add/', login_required(views.profile_add), name='profile_add'),
    path('profile/edit/', login_required(views.edit_my_profile), name='edit_my_profile'),  # NEW: Edit current user's profile
    path('profile/<int:pk>/', views.profile, name='profile'),
    path('profile/<int:pk>/edit/', login_required(views.profile_edit), name='profile_edit'),
    path('profiles/', login_required(views.profile_list), name='profile_list'),
    path('user-profile/<int:pk>/', views.user_profile, name='user_profile'),
    
    # ===========================================
    # STUDY BUDDY MATCHING
    # ===========================================
    path('find-buddies/', login_required(views.find_buddies), name='find_buddies'),
    path('search/', views.search_buddies, name='search_buddies'),
    
    # ===========================================
    # MESSAGING SYSTEM
    # ===========================================
    path('inbox/', login_required(views.inbox), name='inbox'),
    path('send-message/<int:receiver_id>/', login_required(views.send_message), name='send_message'),
    path('chat/<int:user_id>/', login_required(views.chat_thread), name='chat_thread'),
    path('reply/<int:sender_id>/', login_required(views.reply_message), name='reply_message'),
    
    # ===========================================
    # REVIEW SYSTEM
    # ===========================================
    path('review/<int:profile_id>/', login_required(views.leave_review), name='leave_review'),
    path('reviews/', views.reviews_list, name='reviews_list'),  # Reviews list page
    
    # ===========================================
    # COURSE MANAGEMENT
    # ===========================================
    path('courses/', views.course_list, name='course_list'),
    
    # ===========================================
    # STUDY CALENDAR (ORIGINAL)
    # ===========================================
    path('calendar/', login_required(views.study_calendar), name='study_calendar'),
    
    # ===========================================
    # ENHANCED STUDY SESSION MANAGEMENT (NEW)
    # ===========================================
    
    # Main Dashboard and Management
    path('sessions/', login_required(views.study_sessions_dashboard), name='study_sessions_dashboard'),
    path('sessions/create/', login_required(views.create_study_session), name='create_study_session'),
    path('sessions/browse/', login_required(views.browse_study_sessions), name='browse_study_sessions'),
    path('sessions/my-sessions/', login_required(views.user_sessions), name='user_sessions'),
    path('sessions/compatible/', login_required(views.find_compatible_sessions), name='find_compatible_sessions'),
    
    # Session Detail and Actions
    path('sessions/<int:pk>/', views.session_detail, name='session_detail'),
    path('sessions/<int:pk>/join/', login_required(views.join_session), name='join_session'),
    path('sessions/<int:pk>/cancel/', login_required(views.cancel_session), name='cancel_session'),
    path('sessions/<int:pk>/leave/', login_required(views.leave_session), name='leave_session'),
    path('sessions/<int:pk>/checkin/', login_required(views.session_check_in), name='session_check_in'),
    path('sessions/<int:pk>/feedback/', login_required(views.session_feedback), name='session_feedback'),
    
    # Join Request Management
    path('sessions/requests/<int:request_id>/<str:action>/', login_required(views.manage_join_request), name='manage_join_request'),
    
    # Availability Management
    path('availability/', login_required(views.manage_availability), name='manage_availability'),
    path('availability/<int:pk>/delete/', login_required(views.delete_availability), name='delete_availability'),
    
    # AJAX Endpoints
    path('ajax/user-courses/', login_required(views.get_user_courses_ajax), name='get_user_courses_ajax'),
    path('ajax/calendar-data/', login_required(views.session_calendar_data), name='session_calendar_data'),
    
    # ===========================================
    # DEBUG (Remove in production)
    # ===========================================
    path('debug/users/', views.debug_users, name='debug_users'),
]