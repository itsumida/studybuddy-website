from django.contrib import admin
from .models import (
    Profile,
    Course,
    Message,
    Review,
    StudySession,
    
)


admin.site.register(Profile)
admin.site.register(Course)
admin.site.register(Message)
admin.site.register(Review)
admin.site.register(StudySession)




