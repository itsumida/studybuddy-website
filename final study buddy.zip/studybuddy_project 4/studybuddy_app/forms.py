from django import forms
from django.utils import timezone
from datetime import datetime, timedelta
from .models import (
    Profile, Course, Review, Message, PlannedSession,
    EnhancedStudySession, StudySessionRequest, UserAvailability
)
import re

class ProfileAddForm(forms.ModelForm):
    courses = forms.ModelMultipleChoiceField(
        queryset=Course.objects.all(),
        widget=forms.CheckboxSelectMultiple,
        required=True,
        error_messages={
            'required': 'Please select at least one course.'
        }
    )
    
    def clean_email(self):
        email = self.cleaned_data['email']
        pattern = r'^s\d{7}@bi\.no$'
        if not re.match(pattern, email):
            raise forms.ValidationError("Only valid BI emails allowed (e.g., s1234567@bi.no).")
        return email
    
    class Meta:
        model = Profile
        fields = [
            "major", "fname", "lname", "email",
            "bio", "courses"
        ]
        widgets = {
            'bio': forms.Textarea(attrs={
                'rows': 3,
                'placeholder': 'Tell us about yourself and your study preferences...'
            })
        }
    
    def save(self, commit=True):
        instance = super().save(commit=False)
        if commit:
            instance.save()
        return instance


class ProfileEditForm(forms.ModelForm):
    courses = forms.ModelMultipleChoiceField(
        queryset=Course.objects.all(),
        widget=forms.SelectMultiple(attrs={
            'class': 'form-control select2',
        }),
        required=False
    )
    fname = forms.CharField(widget=forms.TextInput(attrs={
        'class': 'form-control',
        'placeholder': 'First name'
    }))
    lname = forms.CharField(widget=forms.TextInput(attrs={
        'class': 'form-control',
        'placeholder': 'Last name'
    }))
    bio = forms.CharField(widget=forms.Textarea(attrs={
        'class': 'form-control',
        'placeholder': 'Tell us about yourself...',
        'rows': 3
    }), required=False)
    major = forms.CharField(widget=forms.TextInput(attrs={
        'class': 'form-control',
        'placeholder': 'Your major'
    }), required=False)
    email = forms.EmailField(widget=forms.EmailInput(attrs={
        'class': 'form-control',
        'placeholder': 's1234567@bi.no'
    }))
    
    def clean_email(self):
        email = self.cleaned_data['email']
        pattern = r'^s\d{7}@bi\.no$'
        if not re.match(pattern, email):
            raise forms.ValidationError("Only valid BI emails allowed (e.g., s1234567@bi.no).")
        return email
    
    class Meta:
        model = Profile
        fields = ['fname', 'lname', 'email', 'bio', 'major', 'courses']


class MessageForm(forms.ModelForm):
    class Meta:
        model = Message
        fields = ['content']
        widgets = {
            'content': forms.Textarea(attrs={'rows': 3, 'placeholder': 'Write your message here...'}),
        }


class PlannedSessionForm(forms.ModelForm):
    class Meta:
        model = PlannedSession
        fields = ['title', 'course', 'date', 'time', 'location']
        widgets = {
            'date': forms.DateInput(attrs={'type': 'date'}),
            'time': forms.TimeInput(attrs={'type': 'time'}),
        }


class ReviewForm(forms.ModelForm):
    class Meta:
        model = Review
        fields = ["rating", "comment"]
        widgets = {
            'comment': forms.Textarea(attrs={'rows': 3, 'placeholder': 'Write your feedback...'}),
        }


# ===========================================
# ENHANCED STUDY SESSION FORMS (NEW)
# ===========================================

class StudySessionForm(forms.ModelForm):
    class Meta:
        model = EnhancedStudySession
        fields = [
            'title', 'description', 'course', 'start_time', 'duration_hours',
            'session_type', 'location', 'virtual_link', 'max_participants',
            'study_topics', 'study_method', 'difficulty_level'
        ]
        widgets = {
            'title': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'e.g., Calculus Problem Solving Session'
            }),
            'description': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 4,
                'placeholder': 'Describe what you want to study and your goals for this session...'
            }),
            'course': forms.Select(attrs={'class': 'form-control'}),
            'start_time': forms.DateTimeInput(attrs={
                'class': 'form-control',
                'type': 'datetime-local',
                'min': timezone.now().strftime('%Y-%m-%dT%H:%M')
            }),
            'duration_hours': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': 1,
                'max': 8,
                'value': 2
            }),
            'session_type': forms.Select(attrs={'class': 'form-control'}),
            'location': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Library Room 205 or Virtual'
            }),
            'virtual_link': forms.URLInput(attrs={
                'class': 'form-control',
                'placeholder': 'https://zoom.us/j/... (if virtual)'
            }),
            'max_participants': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': 2,
                'max': 10,
                'value': 4
            }),
            'study_topics': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'e.g., Chapter 5: Integration, Practice problems 1-20'
            }),
            'study_method': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'e.g., Flashcards, Problem solving, Discussion'
            }),
            'difficulty_level': forms.Select(attrs={'class': 'form-control'}),
        }

    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)
        
        # Filter courses to only show user's enrolled courses
        if self.user and hasattr(self.user, 'profile'):
            self.fields['course'].queryset = self.user.profile.courses.all()
        
        # Set minimum datetime to now
        self.fields['start_time'].widget.attrs['min'] = timezone.now().strftime('%Y-%m-%dT%H:%M')

    def clean_start_time(self):
        start_time = self.cleaned_data['start_time']
        if start_time < timezone.now():
            raise forms.ValidationError("Start time cannot be in the past.")
        return start_time

    def clean(self):
        cleaned_data = super().clean()
        start_time = cleaned_data.get('start_time')
        duration_hours = cleaned_data.get('duration_hours')
        session_type = cleaned_data.get('session_type')
        virtual_link = cleaned_data.get('virtual_link')
        location = cleaned_data.get('location')

        if start_time and duration_hours:
            end_time = start_time + timedelta(hours=duration_hours)
            cleaned_data['end_time'] = end_time

        # Validate virtual session has a link
        if session_type == 'virtual' and not virtual_link:
            raise forms.ValidationError("Virtual sessions must include a meeting link.")

        # Validate physical session has a location
        if session_type == 'physical' and not location:
            raise forms.ValidationError("Physical sessions must include a location.")

        return cleaned_data


class JoinSessionForm(forms.ModelForm):
    class Meta:
        model = StudySessionRequest
        fields = ['message']
        widgets = {
            'message': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Optional: Tell the organizer why you want to join this session...'
            })
        }


class UserAvailabilityForm(forms.ModelForm):
    class Meta:
        model = UserAvailability
        fields = ['day_of_week', 'start_time', 'end_time', 'is_available']
        widgets = {
            'day_of_week': forms.Select(attrs={'class': 'form-control'}),
            'start_time': forms.TimeInput(attrs={
                'class': 'form-control',
                'type': 'time'
            }),
            'end_time': forms.TimeInput(attrs={
                'class': 'form-control',
                'type': 'time'
            }),
            'is_available': forms.CheckboxInput(attrs={'class': 'form-check-input'})
        }

    def clean(self):
        cleaned_data = super().clean()
        start_time = cleaned_data.get('start_time')
        end_time = cleaned_data.get('end_time')

        if start_time and end_time and start_time >= end_time:
            raise forms.ValidationError("End time must be after start time.")

        return cleaned_data


class SessionSearchForm(forms.Form):
    course = forms.ModelChoiceField(
        queryset=None,
        required=False,
        empty_label="All Courses",
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    
    date_from = forms.DateField(
        required=False,
        widget=forms.DateInput(attrs={
            'class': 'form-control',
            'type': 'date',
            'value': timezone.now().date()
        })
    )
    
    date_to = forms.DateField(
        required=False,
        widget=forms.DateInput(attrs={
            'class': 'form-control',
            'type': 'date',
            'value': (timezone.now().date() + timedelta(days=7))
        })
    )
    
    session_type = forms.ChoiceField(
        choices=[('', 'All Types')] + EnhancedStudySession.SESSION_TYPES,
        required=False,
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    
    difficulty_level = forms.ChoiceField(
        choices=[('', 'All Levels')] + [
            ('beginner', 'Beginner'),
            ('intermediate', 'Intermediate'),
            ('advanced', 'Advanced'),
            ('exam_prep', 'Exam Preparation'),
        ],
        required=False,
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    
    available_spots_only = forms.BooleanField(
        required=False,
        initial=True,
        widget=forms.CheckboxInput(attrs={'class': 'form-check-input'})
    )

    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)
        
        if user and hasattr(user, 'profile'):
            # Show all courses, not just user's courses for broader search
            self.fields['course'].queryset = Course.objects.all()


class SessionFeedbackForm(forms.Form):
    rating = forms.ChoiceField(
        choices=[(i, f"{i} Star{'s' if i != 1 else ''}") for i in range(1, 6)],
        widget=forms.RadioSelect(attrs={'class': 'form-check-input'})
    )
    
    feedback = forms.CharField(
        widget=forms.Textarea(attrs={
            'class': 'form-control',
            'rows': 4,
            'placeholder': 'How was the session? What worked well? What could be improved?'
        }),
        required=False
    )