from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MinValueValidator, MaxValueValidator
from django.utils import timezone

class TimestampModel(models.Model):
    """Abstract base model with created_at and updated_at fields"""
    created_at = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    updated_at = models.DateTimeField(auto_now=True, null=True, blank=True)

    class Meta:
        abstract = True

# -------------------------------------
# COURSE
# -------------------------------------
class Course(TimestampModel):
    code = models.CharField(max_length=10, unique=True)
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    # credits = models.PositiveSmallIntegerField(default=3)

    class Meta:
        ordering = ['code']

    def __str__(self):
        return f"{self.code} - {self.name}"

# -------------------------------------
# STATUS
# -------------------------------------
class Status(TimestampModel):
    name = models.CharField(max_length=50, unique=True)
    description = models.CharField(max_length=100, blank=True)

    class Meta:
        verbose_name_plural = "statuses"
        ordering = ['name']

    def __str__(self):
        return self.name

# -------------------------------------
# PROFILE
# -------------------------------------
class Profile(TimestampModel):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    fname = models.CharField("First name", max_length=50)
    lname = models.CharField("Last name", max_length=50)
    email = models.EmailField(unique=True)
    bio = models.TextField(blank=True)
    availability = models.CharField(max_length=100, blank=True)  # Dynamically updated if needed
    courses = models.ManyToManyField(Course, blank=True, related_name='students')
    study_methods = models.CharField(max_length=200, blank=True)
    rating = models.FloatField(default=0.0, validators=[MinValueValidator(0.0), MaxValueValidator(5.0)])
    status = models.ForeignKey(Status, on_delete=models.SET_NULL, null=True, blank=True)
    picture = models.ImageField(upload_to='profile_pics/', blank=True, null=True)
    major = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        ordering = ['lname', 'fname']

    def __str__(self):
        return f"{self.fname} {self.lname}"

    def full_name(self):
        return f"{self.fname} {self.lname}"

# -------------------------------------
# STUDY MATCH
# -------------------------------------
class Match(TimestampModel):
    profile1 = models.ForeignKey(Profile, on_delete=models.CASCADE, related_name='matches_as_first')
    profile2 = models.ForeignKey(Profile, on_delete=models.CASCADE, related_name='matches_as_second')
    course = models.ForeignKey(Course, on_delete=models.CASCADE)

    class Meta:
        unique_together = ('profile1', 'profile2', 'course')

    def __str__(self):
        return f"{self.profile1.full_name()} & {self.profile2.full_name()} — {self.course.code}"

# -------------------------------------
# MESSAGE
# -------------------------------------
class Message(models.Model):
    content = models.TextField()
    read = models.BooleanField(default=False)
    receiver = models.ForeignKey(User, related_name='received_messages', on_delete=models.CASCADE)
    sender = models.ForeignKey(User, related_name='sent_messages', on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    replied_to = models.ForeignKey('self', null=True, blank=True, on_delete=models.SET_NULL)

    def __str__(self):
        return f"From {self.sender.username} to {self.receiver.username}"

# -------------------------------------
# REVIEW
# -------------------------------------
class Review(TimestampModel):
    reviewer = models.ForeignKey(
        User, 
        related_name='given_reviews', 
        on_delete=models.CASCADE
    )
    reviewed_user = models.ForeignKey(
        User, 
        related_name='received_reviews', 
        on_delete=models.CASCADE
    )
    rating = models.IntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(5)]
    )
    comment = models.TextField()

    class Meta:
        unique_together = [['reviewer', 'reviewed_user']]
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.reviewer.username} → {self.reviewed_user.username} ({self.rating}/5)"

# -------------------------------------
# EXISTING STUDY SESSION (SIMPLIFIED)
# -------------------------------------
class StudySession(TimestampModel):
    creator = models.ForeignKey(
        User, 
        on_delete=models.CASCADE,
        related_name='created_sessions'
    )
    course = models.ForeignKey(
        Course, 
        on_delete=models.CASCADE,
        related_name='sessions'
    )
    topic = models.CharField(max_length=200)
    scheduled_time = models.DateTimeField()
    location = models.CharField(max_length=200)
    participants = models.ManyToManyField(
        User, 
        related_name='attending_sessions',
        blank=True
    )
    max_participants = models.PositiveSmallIntegerField(
        default=5,
        validators=[MinValueValidator(2), MaxValueValidator(20)]
    )

    class Meta:
        ordering = ['scheduled_time']

    def __str__(self):
        return f"{self.topic} - {self.course.code} @ {self.scheduled_time}"

class PlannedSession(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='planned_sessions')
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='planned_sessions', null=True, blank=True)
    title = models.CharField(max_length=100)
    date = models.DateField()
    time = models.TimeField()
    location = models.CharField(max_length=200, blank=True)

    def __str__(self):
        return f"{self.title} on {self.date} at {self.time}"

# ===========================================
# ENHANCED STUDY SESSION MODELS (NEW)
# ===========================================

class EnhancedStudySession(models.Model):
    """Enhanced study session model with advanced features"""
    SESSION_TYPES = [
        ('virtual', 'Virtual (Online)'),
        ('physical', 'Physical (In-Person)'),
    ]
    
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('confirmed', 'Confirmed'),
        ('completed', 'Completed'),
        ('cancelled', 'Cancelled'),
    ]
    
    DIFFICULTY_CHOICES = [
        ('beginner', 'Beginner'),
        ('intermediate', 'Intermediate'),
        ('advanced', 'Advanced'),
        ('exam_prep', 'Exam Preparation'),
    ]
    
    # Basic session info
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='enhanced_sessions')
    
    # Participants
    organizer = models.ForeignKey(User, on_delete=models.CASCADE, related_name='organized_sessions')
    participants = models.ManyToManyField(User, related_name='joined_study_sessions', blank=True)
    max_participants = models.PositiveIntegerField(default=4, validators=[MinValueValidator(2), MaxValueValidator(10)])
    
    # Timing
    start_time = models.DateTimeField()
    end_time = models.DateTimeField()
    duration_hours = models.PositiveIntegerField(help_text="Duration in hours")
    
    # Location
    session_type = models.CharField(max_length=10, choices=SESSION_TYPES, default='virtual')
    location = models.CharField(max_length=300, blank=True, help_text="Physical address")
    virtual_link = models.URLField(blank=True, help_text="Zoom, Google Meet, etc.")
    
    # Status and metadata
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    # Study preferences
    study_topics = models.TextField(blank=True, help_text="Specific topics to cover")
    study_method = models.CharField(max_length=200, blank=True, help_text="Flashcards, problem-solving, etc.")
    difficulty_level = models.CharField(max_length=50, choices=DIFFICULTY_CHOICES, default='intermediate')
    
    class Meta:
        ordering = ['start_time']
    
    def __str__(self):
        return f"{self.title} - {self.start_time.strftime('%Y-%m-%d %H:%M')}"
    
    @property
    def is_full(self):
        return self.participants.count() >= self.max_participants
    
    @property
    def available_spots(self):
        return self.max_participants - self.participants.count()
    
    @property
    def is_past(self):
        return self.end_time < timezone.now()
    
    @property
    def is_upcoming(self):
        return self.start_time > timezone.now()
    
    @property
    def duration_display(self):
        return f"{self.duration_hours} hour{'s' if self.duration_hours != 1 else ''}"


class StudySessionRequest(models.Model):
    """Model for handling join requests to study sessions"""
    REQUEST_STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ]
    
    session = models.ForeignKey(EnhancedStudySession, on_delete=models.CASCADE, related_name='join_requests')
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    message = models.TextField(blank=True, help_text="Optional message to the organizer")
    status = models.CharField(max_length=20, choices=REQUEST_STATUS_CHOICES, default='pending')
    created_at = models.DateTimeField(auto_now_add=True)
    responded_at = models.DateTimeField(null=True, blank=True)
    
    class Meta:
        unique_together = ['session', 'user']
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.user.username} → {self.session.title} ({self.status})"


class UserAvailability(models.Model):
    """Model for storing user's general availability"""
    DAYS_OF_WEEK = [
        (0, 'Monday'),
        (1, 'Tuesday'),
        (2, 'Wednesday'),
        (3, 'Thursday'),
        (4, 'Friday'),
        (5, 'Saturday'),
        (6, 'Sunday'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='availability')
    day_of_week = models.IntegerField(choices=DAYS_OF_WEEK)
    start_time = models.TimeField()
    end_time = models.TimeField()
    is_available = models.BooleanField(default=True)
    
    class Meta:
        unique_together = ['user', 'day_of_week', 'start_time']
        ordering = ['day_of_week', 'start_time']
    
    def __str__(self):
        day_name = dict(self.DAYS_OF_WEEK)[self.day_of_week]
        return f"{self.user.username} - {day_name} {self.start_time}-{self.end_time}"


class SessionReminder(models.Model):
    """Model for managing session reminders"""
    REMINDER_TYPES = [
        ('24h', '24 hours before'),
        ('1h', '1 hour before'),
        ('15m', '15 minutes before'),
    ]
    
    session = models.ForeignKey(EnhancedStudySession, on_delete=models.CASCADE, related_name='reminders')
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    reminder_type = models.CharField(max_length=10, choices=REMINDER_TYPES)
    is_sent = models.BooleanField(default=False)
    sent_at = models.DateTimeField(null=True, blank=True)
    
    class Meta:
        unique_together = ['session', 'user', 'reminder_type']
    
    def __str__(self):
        return f"Reminder for {self.user.username} - {self.session.title} ({self.reminder_type})"


class SessionAttendance(models.Model):
    """Track who actually attended sessions"""
    session = models.ForeignKey(EnhancedStudySession, on_delete=models.CASCADE, related_name='attendance')
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    attended = models.BooleanField(default=False)
    check_in_time = models.DateTimeField(null=True, blank=True)
    rating = models.IntegerField(null=True, blank=True, validators=[MinValueValidator(1), MaxValueValidator(5)])
    feedback = models.TextField(blank=True)
    
    class Meta:
        unique_together = ['session', 'user']
    
    def __str__(self):
        status = "Attended" if self.attended else "Did not attend"
        return f"{self.user.username} - {self.session.title} ({status})"