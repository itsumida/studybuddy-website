from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.models import User
from django.db.models import Q, Avg, Count, F
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.core.exceptions import PermissionDenied, ObjectDoesNotExist
from django.http import Http404, HttpResponseForbidden, JsonResponse
from django.urls import reverse
from django.core.paginator import Paginator
from django.utils import timezone
from datetime import datetime, timedelta

from .forms import (
    ProfileAddForm, ReviewForm, ProfileEditForm, MessageForm, PlannedSessionForm,
    StudySessionForm, JoinSessionForm, UserAvailabilityForm, 
    SessionSearchForm, SessionFeedbackForm
)
from .models import (
    Profile, Message, StudySession, Review, Course, Match, PlannedSession,
    EnhancedStudySession, StudySessionRequest, UserAvailability, 
    SessionAttendance, SessionReminder
)


def create_matches_for_profile(profile):
    """Create matches for a profile based on shared courses"""
    others = Profile.objects.exclude(id=profile.id)

    for other in others:
        shared_courses = profile.courses.filter(id__in=other.courses.values_list("id", flat=True))
        for course in shared_courses:
            # Ensure order is consistent (profile1.id < profile2.id)
            profile1, profile2 = sorted([profile, other], key=lambda p: p.id)

            Match.objects.get_or_create(
                profile1=profile1,
                profile2=profile2,
                course=course
            )


# ---------------------------------------
# Main Views
# ---------------------------------------
def index(request):
    """Homepage view"""
    try:
        featured_profiles = None
        has_unread = False

        if request.user.is_authenticated:
            featured_profiles = Profile.objects.exclude(user=request.user).order_by('?')[:3]
            has_unread = Message.objects.filter(receiver=request.user, read=False).exists()

        return render(request, 'studybuddy_app/index.html', {
            'featured_profiles': featured_profiles,
            'has_unread': has_unread
        })

    except Exception as e:
        messages.error(request, "An error occurred while loading the homepage.")
        return render(request, 'studybuddy_app/index.html', {
            'has_unread': False
        })


def signup(request):
    """User signup view"""
    if request.user.is_authenticated:
        messages.info(request, "You're already logged in.")
        return redirect('studybuddy_app:index')
        
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            try:
                user = form.save()
                # Log in the user immediately after signup
                login(request, user)
                messages.success(request, f"Welcome to StudyBuddy, {user.username}! Please create your profile.")
                return redirect('studybuddy_app:profile_add')
            except Exception as e:
                messages.error(request, f"Error creating account: {str(e)}")
        else:
            # Display specific form errors
            for field, errors in form.errors.items():
                for error in errors:
                    if field == '__all__':
                        messages.error(request, error)
                    else:
                        messages.error(request, f"{field.title()}: {error}")
    else:
        form = UserCreationForm()
    
    return render(request, 'studybuddy_app/signup.html', {'form': form})


def user_login(request):
    """User login view with enhanced debugging"""
    if request.user.is_authenticated:
        return redirect('studybuddy_app:index')
        
    if request.method == 'POST':
        # Enhanced debugging
        print("=" * 50)
        print("LOGIN ATTEMPT DEBUG INFO:")
        print(f"Raw POST data: {dict(request.POST)}")
        
        form = AuthenticationForm(request, data=request.POST)
        print(f"Form is valid: {form.is_valid()}")
        
        if not form.is_valid():
            print(f"Form errors: {form.errors}")
            print(f"Non-field errors: {form.non_field_errors()}")
            
            # Check specific field errors
            for field_name, field_errors in form.errors.items():
                print(f"{field_name} errors: {field_errors}")
        
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            print(f"Cleaned username: '{username}', password length: {len(password)}")
            
            # Check if user exists in database
            try:
                user_obj = User.objects.get(username=username)
                print(f"User found in DB: {user_obj.username}, Active: {user_obj.is_active}, ID: {user_obj.id}")
                
                # Check if password is correct
                if user_obj.check_password(password):
                    print("Password check: CORRECT")
                else:
                    print("Password check: INCORRECT")
                    
            except User.DoesNotExist:
                print(f"User '{username}' NOT FOUND in database")
                # Show all users for debugging
                all_users = User.objects.all()
                print(f"All users in database ({all_users.count()}): {[u.username for u in all_users]}")
            
            # Try authentication
            user = authenticate(request, username=username, password=password)
            print(f"Authentication result: {user}")
            
            if user is not None:
                login(request, user)
                messages.success(request, f"Welcome back, {username}!")
                print(f"Login successful for user: {user.username}")
                
                # Check if user has a profile
                try:
                    profile = Profile.objects.get(user=user)
                    print(f"User has profile, redirecting to profile page")
                    return redirect('studybuddy_app:profile', pk=profile.pk)
                except Profile.DoesNotExist:
                    print(f"User has no profile, redirecting to create profile")
                    return redirect('studybuddy_app:profile_add')
            else:
                print("Authentication failed - returning error message")
                messages.error(request, "Invalid username or password.")
        else:
            print("Form validation failed")
            messages.error(request, "Please check your username and password.")
            
        print("=" * 50)
    else:
        form = AuthenticationForm()
    
    return render(request, 'studybuddy_app/login.html', {'form': form})


def user_logout(request):
    """User logout view"""
    if request.user.is_authenticated:
        username = request.user.username
        logout(request)
        messages.success(request, f"Goodbye {username}! You have been logged out.")
    return redirect('studybuddy_app:index')


def more_about(request):
    """About page view"""
    return render(request, 'studybuddy_app/profile/more_about.html')


# ---------------------------------------
# Profile Views
# ---------------------------------------
def profile(request, pk):
    """Display user profile"""
    try:
        profile = get_object_or_404(Profile, pk=pk)
        
        # Get sessions only if the viewing user is authenticated and it's their own profile
        sessions = []
        if request.user.is_authenticated and request.user == profile.user:
            sessions = PlannedSession.objects.filter(
                user=request.user, 
                date__gte=timezone.now().date()
            ).order_by('date', 'time')
        
        reviews = Review.objects.filter(reviewed_user=profile.user).select_related('reviewer')
        can_review = (
            request.user.is_authenticated and
            request.user != profile.user and 
            not Review.objects.filter(reviewer=request.user, reviewed_user=profile.user).exists()
        )

        return render(request, 'studybuddy_app/profile/profile.html', {
            'profile': profile,
            'reviews': reviews,
            'can_review': can_review,
            'sessions': sessions
        })
    except Exception as e:
        messages.error(request, f"Error loading profile: {str(e)}")
        return redirect('studybuddy_app:profile_list')


@login_required
def profile_list(request):
    """List all user profiles with pagination"""
    try:
        profiles = Profile.objects.exclude(user=request.user).select_related('user')
        paginator = Paginator(profiles, 10)  # Show 10 profiles per page
        page_number = request.GET.get('page')
        page_obj = paginator.get_page(page_number)
        return render(request, 'studybuddy_app/profile/profile_list.html', {'page_obj': page_obj})
    except Exception as e:
        messages.error(request, f"Error loading profiles: {e}")
        return render(request, 'studybuddy_app/profile/profile_list.html', {'page_obj': None})


@login_required
def profile_add(request):
    """Create a new user profile"""
    # Check if user already has a profile
    try:
        profile = request.user.profile
        messages.info(request, "You already have a profile.")
        return redirect('studybuddy_app:profile', pk=profile.pk)
    except ObjectDoesNotExist:
        pass

    if request.method == "POST":
        form = ProfileAddForm(request.POST, request.FILES)
        if form.is_valid():
            try:
                profile = form.save(commit=False)
                profile.user = request.user
                profile.save()
                form.save_m2m()
                create_matches_for_profile(profile)
                messages.success(request, "Profile created successfully!")
                return redirect('studybuddy_app:profile', pk=profile.pk)
            except Exception as e:
                messages.error(request, f"Error saving profile: {str(e)}")
        else:
            messages.error(request, "Please correct the errors below.")
    else:
        form = ProfileAddForm()

    return render(request, 'studybuddy_app/profile/profile_add.html', {'form': form})


@login_required
def edit_my_profile(request):
    """Redirect to edit the current user's own profile"""
    try:
        profile = request.user.profile
        return redirect('studybuddy_app:profile_edit', pk=profile.pk)
    except:
        # If user doesn't have a profile yet, redirect to create one
        return redirect('studybuddy_app:profile_add')


@login_required
def profile_edit(request, pk):
    """Edit user profile"""
    profile = get_object_or_404(Profile, pk=pk)

    # Check if the logged-in user matches the profile user
    if request.user != profile.user:
        messages.error(request, "You are not authorized to edit this profile.")
        return redirect('studybuddy_app:profile', pk=profile.pk)

    if request.method == 'POST':
        form = ProfileEditForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            try:
                profile = form.save(commit=False)
                profile.user = request.user
                profile.save()
                form.save_m2m()
                create_matches_for_profile(profile)
                messages.success(request, "Profile updated successfully!")
                return redirect('studybuddy_app:profile', pk=profile.pk)
            except Exception as e:
                messages.error(request, f"Error saving profile: {str(e)}")
        else:
            messages.error(request, "Please correct the errors below.")
    else:
        form = ProfileEditForm(instance=profile)

    return render(request, 'studybuddy_app/profile/profile_edit.html', {'form': form, 'profile': profile})


def user_profile(request, pk):
    """View another user's profile and send message"""
    target_profile = get_object_or_404(Profile, pk=pk)
    message_sent = False

    if request.method == 'POST' and request.user.is_authenticated:
        form = MessageForm(request.POST)
        if form.is_valid():
            message = form.save(commit=False)
            message.sender = request.user
            message.receiver = target_profile.user
            message.save()
            message_sent = True
            messages.success(request, "Message sent successfully!")
            form = MessageForm()  # Clear form after submission
        else:
            messages.error(request, "Error sending message.")
    else:
        form = MessageForm()

    return render(request, 'studybuddy_app/profile/profile_user_info.html', {
        'profile': target_profile,
        'form': form,
        'message_sent': message_sent
    })


@login_required
def find_buddies(request):
    """Find study buddies based on matches"""
    try:
        profile = request.user.profile
        matches = Match.objects.filter(Q(profile1=profile) | Q(profile2=profile))

        matched_profiles = {}
        for match in matches:
            other = match.profile2 if match.profile1 == profile else match.profile1
            matched_profiles.setdefault(other, []).append(match.course)

        return render(request, 'studybuddy_app/profile/find_buddies.html', {
            'matched_profiles': matched_profiles
        })
    except ObjectDoesNotExist:
        messages.error(request, "Please create a profile first to find study buddies.")
        return redirect('studybuddy_app:profile_add')
    except Exception as e:
        messages.error(request, f"Error finding buddies: {str(e)}")
        return redirect('studybuddy_app:index')


# ---------------------------------------
# Messaging System
# ---------------------------------------
@login_required
def send_message(request, receiver_id):
    """Send a message to another user"""
    receiver = get_object_or_404(User, id=receiver_id)

    # Prevent sending message to yourself
    if receiver == request.user:
        messages.error(request, "You cannot send a message to yourself.")
        return redirect('studybuddy_app:inbox')

    if request.method == 'POST':
        content = request.POST.get('content', '').strip()
        if content:
            try:
                Message.objects.create(
                    sender=request.user,
                    receiver=receiver,
                    content=content
                )
                messages.success(request, "Message sent successfully!")
                return redirect('studybuddy_app:chat_thread', user_id=receiver.id)
            except Exception as e:
                messages.error(request, "Error sending message.")
        else:
            messages.error(request, "Message cannot be empty.")
    
    return render(request, 'studybuddy_app/messages/send_message.html', {'receiver': receiver})


@login_required
def inbox(request):
    """Display user's message inbox"""
    user = request.user

    # Mark all unread messages as read
    Message.objects.filter(receiver=user, read=False).update(read=True)

    all_messages = Message.objects.filter(
        Q(sender=user) | Q(receiver=user)
    ).exclude(sender=user, receiver=user).order_by('-created_at')

    threads = {}
    for msg in all_messages:
        other_user = msg.receiver if msg.sender == user else msg.sender
        if other_user.id not in threads:
            threads[other_user.id] = {
                'user': other_user,
                'last_message': msg
            }

    return render(request, 'studybuddy_app/messages/inbox.html', {
        'threads': threads.values()
    })


@login_required
def chat_thread(request, user_id):
    """Display chat thread with another user"""
    if user_id == request.user.id:
        messages.error(request, "You cannot chat with yourself.")
        return redirect('studybuddy_app:inbox')

    partner = get_object_or_404(User, id=user_id)

    messages_received = Message.objects.filter(
        Q(sender=request.user, receiver=partner) |
        Q(sender=partner, receiver=request.user)
    ).exclude(sender=request.user, receiver=request.user).order_by('created_at')

    if request.method == 'POST':
        content = request.POST.get('content', '').strip()
        if content:
            try:
                Message.objects.create(
                    sender=request.user,
                    receiver=partner,
                    content=content
                )
                return redirect('studybuddy_app:chat_thread', user_id=partner.id)
            except Exception as e:
                messages.error(request, "Error sending message.")

    return render(request, 'studybuddy_app/messages/chat_thread.html', {
        'messages_received': messages_received,
        'receiver': partner,
    })


@login_required
def reply_message(request, sender_id):
    """Reply to a specific message"""
    original_message = get_object_or_404(Message, id=sender_id)
    
    if request.method == 'POST':
        form = MessageForm(request.POST)
        if form.is_valid():
            reply = form.save(commit=False)
            reply.sender = request.user
            reply.receiver = original_message.sender
            reply.replied_to = original_message
            reply.save()
            messages.success(request, "Reply sent successfully!")
            return redirect('studybuddy_app:inbox')
        else:
            messages.error(request, "Error sending reply.")
    else:
        form = MessageForm()

    return render(request, 'studybuddy_app/messages/reply.html', {
        'form': form,
        'original_message': original_message,
    })


# ---------------------------------------
# Review System
# ---------------------------------------
@login_required
def leave_review(request, profile_id):
    """Leave a review for another user"""
    profile = get_object_or_404(Profile, id=profile_id)
    
    if request.user == profile.user:
        messages.error(request, "You cannot review yourself.")
        return redirect('studybuddy_app:profile', pk=profile_id)
        
    if Review.objects.filter(reviewer=request.user, reviewed_user=profile.user).exists():
        messages.error(request, "You have already reviewed this user.")
        return redirect('studybuddy_app:profile', pk=profile_id)

    if request.method == 'POST':
        form = ReviewForm(request.POST)
        if form.is_valid():
            try:
                review = form.save(commit=False)
                review.reviewer = request.user
                review.reviewed_user = profile.user
                review.save()
                messages.success(request, "Review submitted successfully!")
                return redirect('studybuddy_app:profile', pk=profile_id)
            except Exception as e:
                messages.error(request, "Error submitting review.")
        else:
            messages.error(request, "Please correct the errors below.")
    else:
        form = ReviewForm()
    
    return render(request, 'studybuddy_app/leave_review.html', {
        'form': form,
        'profile': profile
    })


def reviews_list(request):
    """Display all reviews with filtering and pagination"""
    try:
        # Get filter parameters
        rating_filter = request.GET.get('rating', '')
        sort_by = request.GET.get('sort', 'newest')
        
        # Start with all reviews
        reviews = Review.objects.select_related('reviewer', 'reviewed_user').all()
        
        # Apply rating filter
        if rating_filter and rating_filter.isdigit():
            rating_value = int(rating_filter)
            reviews = reviews.filter(rating__gte=rating_value)
        
        # Apply sorting
        if sort_by == 'newest':
            reviews = reviews.order_by('-created_at')
        elif sort_by == 'oldest':
            reviews = reviews.order_by('created_at')
        elif sort_by == 'highest':
            reviews = reviews.order_by('-rating', '-created_at')
        elif sort_by == 'lowest':
            reviews = reviews.order_by('rating', '-created_at')
        else:
            reviews = reviews.order_by('-created_at')
        
        # Calculate statistics
        stats = Review.objects.aggregate(
            total_reviews=Count('id'),
            average_rating=Avg('rating'),
            five_star_count=Count('id', filter=Q(rating=5)),
            active_reviewers=Count('reviewer', distinct=True)
        )
        
        # Handle None values
        total_reviews = stats['total_reviews'] or 0
        average_rating = stats['average_rating'] or 0
        five_star_reviews = stats['five_star_count'] or 0
        active_reviewers = stats['active_reviewers'] or 0
        
        # Pagination
        paginator = Paginator(reviews, 12)  # Show 12 reviews per page
        page_number = request.GET.get('page')
        page_obj = paginator.get_page(page_number)
        
        return render(request, 'studybuddy_app/reviews_list.html', {
            'page_obj': page_obj,
            'total_reviews': total_reviews,
            'average_rating': average_rating,
            'five_star_reviews': five_star_reviews,
            'active_reviewers': active_reviewers,
        })
        
    except Exception as e:
        messages.error(request, "Error loading reviews.")
        return render(request, 'studybuddy_app/reviews_list.html', {
            'page_obj': None,
            'total_reviews': 0,
            'average_rating': 0,
            'five_star_reviews': 0,
            'active_reviewers': 0,
        })


# ---------------------------------------
# Course Views
# ---------------------------------------
def course_list(request):
    """List all available courses with pagination"""
    try:
        courses = Course.objects.all().order_by('code')
        paginator = Paginator(courses, 10)  # Show 10 courses per page
        page_number = request.GET.get('page')
        page_obj = paginator.get_page(page_number)
        return render(request, 'studybuddy_app/course/course_list.html', {'page_obj': page_obj})
    except Exception as e:
        messages.error(request, "Error loading courses.")
        return render(request, 'studybuddy_app/course/course_list.html', {'page_obj': None})


# ---------------------------------------
# Search Functionality
# ---------------------------------------
def search_buddies(request):
    """Search for study buddies based on various criteria"""
    query = request.GET.get('q', '').strip()
    
    try:
        if query:
            results = Profile.objects.filter(
                Q(courses__name__icontains=query) |
                Q(study_methods__icontains=query) |
                Q(bio__icontains=query) |
                Q(user__username__icontains=query)
            ).exclude(user=request.user if request.user.is_authenticated else None).distinct()
            
            paginator = Paginator(results, 10)  # Show 10 results per page
            page_number = request.GET.get('page')
            page_obj = paginator.get_page(page_number)
        else:
            page_obj = None
            messages.info(request, "Please enter a search term.")
        
        return render(request, 'studybuddy_app/search_results.html', {
            'page_obj': page_obj,
            'query': query
        })
    except Exception as e:
        messages.error(request, "Error performing search.")
        return render(request, 'studybuddy_app/search_results.html', {
            'page_obj': None, 
            'query': query
        })


# ---------------------------------------
# Study Calendar (Original)
# ---------------------------------------
@login_required
def study_calendar(request):
    """View study sessions calendar"""
    try:
        sessions = StudySession.objects.filter(
            Q(creator=request.user) | 
            Q(participants=request.user)
        ).distinct().order_by('scheduled_time')
        
        return render(request, 'studybuddy_app/calendar.html', {
            'sessions': sessions
        })
    except Exception as e:
        messages.error(request, "Error loading calendar.")
        return render(request, 'studybuddy_app/calendar.html', {'sessions': None})


# ===========================================
# ENHANCED STUDY SESSION VIEWS (NEW)
# ===========================================

@login_required
def study_sessions_dashboard(request):
    """Main dashboard for study sessions"""
    try:
        # Get user's upcoming sessions
        upcoming_sessions = EnhancedStudySession.objects.filter(
            Q(organizer=request.user) | Q(participants=request.user),
            start_time__gt=timezone.now(),
            status__in=['pending', 'confirmed']
        ).distinct().order_by('start_time')[:5]
        
        # Get user's organized sessions
        organized_sessions = EnhancedStudySession.objects.filter(
            organizer=request.user
        ).order_by('-created_at')[:3]
        
        # Get pending join requests for user's sessions
        pending_requests = StudySessionRequest.objects.filter(
            session__organizer=request.user,
            status='pending'
        ).select_related('user', 'session')[:5]
        
        # Get user's pending requests to join other sessions
        user_pending_requests = StudySessionRequest.objects.filter(
            user=request.user,
            status='pending'
        ).select_related('session')[:5]
        
        # Quick stats
        stats = {
            'total_organized': EnhancedStudySession.objects.filter(organizer=request.user).count(),
            'total_joined': EnhancedStudySession.objects.filter(participants=request.user).count(),
            'pending_requests': pending_requests.count(),
            'completed_sessions': EnhancedStudySession.objects.filter(
                Q(organizer=request.user) | Q(participants=request.user),
                status='completed'
            ).distinct().count()
        }
        
        return render(request, 'studybuddy_app/sessions/dashboard.html', {
            'upcoming_sessions': upcoming_sessions,
            'organized_sessions': organized_sessions,
            'pending_requests': pending_requests,
            'user_pending_requests': user_pending_requests,
            'stats': stats
        })
        
    except Exception as e:
        messages.error(request, f"Error loading dashboard: {str(e)}")
        return render(request, 'studybuddy_app/sessions/dashboard.html', {
            'upcoming_sessions': [],
            'organized_sessions': [],
            'pending_requests': [],
            'user_pending_requests': [],
            'stats': {}
        })


@login_required
def create_study_session(request):
    """Create a new study session"""
    if request.method == 'POST':
        form = StudySessionForm(request.POST, user=request.user)
        if form.is_valid():
            try:
                session = form.save(commit=False)
                session.organizer = request.user
                session.end_time = session.start_time + timedelta(hours=session.duration_hours)
                session.save()
                form.save_m2m()
                
                messages.success(request, f"Study session '{session.title}' created successfully!")
                return redirect('studybuddy_app:session_detail', pk=session.pk)
            except Exception as e:
                messages.error(request, f"Error creating session: {str(e)}")
        else:
            messages.error(request, "Please correct the errors below.")
    else:
        form = StudySessionForm(user=request.user)

    return render(request, 'studybuddy_app/sessions/create_session.html', {'form': form})


@login_required
def browse_study_sessions(request):
    """Browse and search available study sessions"""
    form = SessionSearchForm(request.GET, user=request.user)
    
    # Start with all future sessions that aren't full
    sessions = EnhancedStudySession.objects.filter(
        start_time__gt=timezone.now(),
        status__in=['pending', 'confirmed']
    ).select_related('organizer', 'course').prefetch_related('participants')
    
    # Exclude user's own sessions
    sessions = sessions.exclude(organizer=request.user)
    
    # Apply filters if form is valid
    if form.is_valid():
        course = form.cleaned_data.get('course')
        date_from = form.cleaned_data.get('date_from')
        date_to = form.cleaned_data.get('date_to')
        session_type = form.cleaned_data.get('session_type')
        difficulty_level = form.cleaned_data.get('difficulty_level')
        available_spots_only = form.cleaned_data.get('available_spots_only')
        
        if course:
            sessions = sessions.filter(course=course)
        
        if date_from:
            sessions = sessions.filter(start_time__date__gte=date_from)
        
        if date_to:
            sessions = sessions.filter(start_time__date__lte=date_to)
        
        if session_type:
            sessions = sessions.filter(session_type=session_type)
        
        if difficulty_level:
            sessions = sessions.filter(difficulty_level=difficulty_level)
        
        if available_spots_only:
            sessions = sessions.annotate(
                participant_count=Count('participants')
            ).filter(participant_count__lt=F('max_participants'))
    
    # Pagination
    paginator = Paginator(sessions.order_by('start_time'), 12)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    return render(request, 'studybuddy_app/sessions/browse_sessions.html', {
        'form': form,
        'page_obj': page_obj
    })


@login_required
def session_detail(request, pk):
    """View detailed information about a study session"""
    session = get_object_or_404(EnhancedStudySession, pk=pk)
    
    # Check if user can join
    can_join = (
        request.user != session.organizer and
        not session.is_full and
        request.user not in session.participants.all() and
        not StudySessionRequest.objects.filter(
            session=session, user=request.user, status='pending'
        ).exists()
    )
    
    # Check if user has pending request
    user_request = StudySessionRequest.objects.filter(
        session=session, user=request.user
    ).first()
    
    # Get all join requests if user is organizer
    join_requests = []
    if request.user == session.organizer:
        join_requests = StudySessionRequest.objects.filter(
            session=session, status='pending'
        ).select_related('user')
    
    return render(request, 'studybuddy_app/sessions/session_detail.html', {
        'session': session,
        'can_join': can_join,
        'user_request': user_request,
        'join_requests': join_requests
    })


@login_required
def join_session(request, pk):
    """Request to join a study session"""
    session = get_object_or_404(EnhancedStudySession, pk=pk)
    
    # Validation checks
    if request.user == session.organizer:
        messages.error(request, "You cannot join your own session.")
        return redirect('studybuddy_app:session_detail', pk=pk)
    
    if session.is_full:
        messages.error(request, "This session is already full.")
        return redirect('studybuddy_app:session_detail', pk=pk)
    
    if request.user in session.participants.all():
        messages.error(request, "You are already a participant in this session.")
        return redirect('studybuddy_app:session_detail', pk=pk)
    
    # Check if request already exists
    existing_request = StudySessionRequest.objects.filter(
        session=session, user=request.user
    ).first()
    
    if existing_request:
        messages.error(request, f"You already have a {existing_request.status} request for this session.")
        return redirect('studybuddy_app:session_detail', pk=pk)
    
    if request.method == 'POST':
        form = JoinSessionForm(request.POST)
        if form.is_valid():
            try:
                join_request = form.save(commit=False)
                join_request.session = session
                join_request.user = request.user
                join_request.save()
                
                messages.success(request, "Join request sent successfully! The organizer will review your request.")
                return redirect('studybuddy_app:session_detail', pk=pk)
            except Exception as e:
                messages.error(request, f"Error sending join request: {str(e)}")
    else:
        form = JoinSessionForm()
    
    return render(request, 'studybuddy_app/sessions/join_session.html', {
        'form': form,
        'session': session
    })


@login_required
def manage_join_request(request, request_id, action):
    """Approve or reject a join request"""
    join_request = get_object_or_404(StudySessionRequest, pk=request_id)
    
    # Only session organizer can manage requests
    if request.user != join_request.session.organizer:
        messages.error(request, "You don't have permission to manage this request.")
        return redirect('studybuddy_app:session_detail', pk=join_request.session.pk)
    
    if action == 'approve':
        if join_request.session.is_full:
            messages.error(request, "Cannot approve request - session is full.")
        else:
            join_request.status = 'approved'
            join_request.responded_at = timezone.now()
            join_request.save()
            
            # Add user to session participants
            join_request.session.participants.add(join_request.user)
            join_request.session.save()
            
            messages.success(request, f"Approved {join_request.user.username}'s request to join the session.")
    
    elif action == 'reject':
        join_request.status = 'rejected'
        join_request.responded_at = timezone.now()
        join_request.save()
        
        messages.success(request, f"Rejected {join_request.user.username}'s request to join the session.")
    
    return redirect('studybuddy_app:session_detail', pk=join_request.session.pk)


@login_required
def user_sessions(request):
    """View all user's sessions (organized and joined) - FIXED VERSION"""
    # Use a single query with Q objects to avoid the union issue
    all_sessions = EnhancedStudySession.objects.filter(
        Q(organizer=request.user) | Q(participants=request.user)
    ).distinct().order_by('-start_time')
    
    paginator = Paginator(all_sessions, 10)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    return render(request, 'studybuddy_app/sessions/user_sessions.html', {
        'page_obj': page_obj
    })


@login_required
def cancel_session(request, pk):
    """Cancel a study session"""
    session = get_object_or_404(EnhancedStudySession, pk=pk)
    
    # Only organizer can cancel
    if request.user != session.organizer:
        messages.error(request, "You don't have permission to cancel this session.")
        return redirect('studybuddy_app:session_detail', pk=pk)
    
    if request.method == 'POST':
        session.status = 'cancelled'
        session.save()
        
        messages.success(request, f"Session '{session.title}' has been cancelled.")
        return redirect('studybuddy_app:study_sessions_dashboard')
    
    return render(request, 'studybuddy_app/sessions/cancel_session.html', {
        'session': session
    })


@login_required
def leave_session(request, pk):
    """Leave a study session"""
    session = get_object_or_404(EnhancedStudySession, pk=pk)
    
    if request.user not in session.participants.all():
        messages.error(request, "You are not a participant in this session.")
        return redirect('studybuddy_app:session_detail', pk=pk)
    
    if request.method == 'POST':
        session.participants.remove(request.user)
        messages.success(request, f"You have left the session '{session.title}'.")
        return redirect('studybuddy_app:study_sessions_dashboard')
    
    return render(request, 'studybuddy_app/sessions/leave_session.html', {
        'session': session
    })


@login_required
def session_check_in(request, pk):
    """Check into a study session"""
    session = get_object_or_404(EnhancedStudySession, pk=pk)
    
    # Validate user can check in
    if request.user not in session.participants.all() and request.user != session.organizer:
        messages.error(request, "You are not a participant in this session.")
        return redirect('studybuddy_app:session_detail', pk=pk)
    
    # Check if session is happening now (within 15 minutes)
    now = timezone.now()
    if now < session.start_time - timedelta(minutes=15) or now > session.end_time:
        messages.error(request, "Check-in is only available 15 minutes before to session end time.")
        return redirect('studybuddy_app:session_detail', pk=pk)
    
    # Create or update attendance record
    attendance, created = SessionAttendance.objects.get_or_create(
        session=session,
        user=request.user,
        defaults={'attended': True, 'check_in_time': now}
    )
    
    if not created and not attendance.attended:
        attendance.attended = True
        attendance.check_in_time = now
        attendance.save()
    
    messages.success(request, f"Successfully checked in to '{session.title}'!")
    return redirect('studybuddy_app:session_detail', pk=pk)


@login_required
def session_feedback(request, pk):
    """Leave feedback for a completed session"""
    session = get_object_or_404(EnhancedStudySession, pk=pk)
    
    # Validate user attended the session
    attendance = SessionAttendance.objects.filter(
        session=session, user=request.user, attended=True
    ).first()
    
    if not attendance:
        messages.error(request, "You can only leave feedback for sessions you attended.")
        return redirect('studybuddy_app:session_detail', pk=pk)
    
    if attendance.rating and attendance.feedback:
        messages.info(request, "You have already left feedback for this session.")
        return redirect('studybuddy_app:session_detail', pk=pk)
    
    if request.method == 'POST':
        form = SessionFeedbackForm(request.POST)
        if form.is_valid():
            attendance.rating = int(form.cleaned_data['rating'])
            attendance.feedback = form.cleaned_data['feedback']
            attendance.save()
            
            messages.success(request, "Thank you for your feedback!")
            return redirect('studybuddy_app:session_detail', pk=pk)
    else:
        form = SessionFeedbackForm()
    
    return render(request, 'studybuddy_app/sessions/session_feedback.html', {
        'form': form,
        'session': session
    })


@login_required
def manage_availability(request):
    """Manage user's weekly availability"""
    if request.method == 'POST':
        form = UserAvailabilityForm(request.POST)
        if form.is_valid():
            try:
                availability = form.save(commit=False)
                availability.user = request.user
                availability.save()
                messages.success(request, "Availability added successfully!")
                return redirect('studybuddy_app:manage_availability')
            except Exception as e:
                messages.error(request, f"Error saving availability: {str(e)}")
    else:
        form = UserAvailabilityForm()
    
    # Get existing availability
    availability_slots = UserAvailability.objects.filter(
        user=request.user
    ).order_by('day_of_week', 'start_time')
    
    return render(request, 'studybuddy_app/sessions/manage_availability.html', {
        'form': form,
        'availability_slots': availability_slots
    })


@login_required
def delete_availability(request, pk):
    """Delete an availability slot"""
    availability = get_object_or_404(UserAvailability, pk=pk, user=request.user)
    
    if request.method == 'POST':
        availability.delete()
        messages.success(request, "Availability slot deleted.")
    
    return redirect('studybuddy_app:manage_availability')


@login_required
def find_compatible_sessions(request):
    """Find sessions that match user's availability"""
    try:
        # Get user's availability
        user_availability = UserAvailability.objects.filter(
            user=request.user, is_available=True
        )
        
        if not user_availability.exists():
            messages.info(request, "Please set up your availability first to find compatible sessions.")
            return redirect('studybuddy_app:manage_availability')
        
        compatible_sessions = []
        
        # Get all upcoming sessions
        upcoming_sessions = EnhancedStudySession.objects.filter(
            start_time__gt=timezone.now(),
            status__in=['pending', 'confirmed']
        ).exclude(organizer=request.user).select_related('organizer', 'course')
        
        for session in upcoming_sessions:
            session_start = session.start_time
            session_day = session_start.weekday()
            session_time = session_start.time()
            
            # Check if session time matches user's availability
            for availability in user_availability:
                if (availability.day_of_week == session_day and
                    availability.start_time <= session_time <= availability.end_time):
                    compatible_sessions.append(session)
                    break
        
        # Remove duplicates and paginate
        compatible_sessions = list(set(compatible_sessions))
        paginator = Paginator(compatible_sessions, 10)
        page_number = request.GET.get('page')
        page_obj = paginator.get_page(page_number)
        
        return render(request, 'studybuddy_app/sessions/compatible_sessions.html', {
            'page_obj': page_obj
        })
        
    except Exception as e:
        messages.error(request, f"Error finding compatible sessions: {str(e)}")
        return render(request, 'studybuddy_app/sessions/compatible_sessions.html', {'page_obj': None})


# AJAX Views for dynamic functionality
@login_required
def get_user_courses_ajax(request):
    """AJAX endpoint to get user's courses"""
    if hasattr(request.user, 'profile'):
        courses = request.user.profile.courses.all()
        course_data = [{'id': c.id, 'name': f"{c.code} - {c.name}"} for c in courses]
        return JsonResponse({'courses': course_data})
    return JsonResponse({'courses': []})


@login_required
def session_calendar_data(request):
    """AJAX endpoint for calendar data"""
    start_date = request.GET.get('start')
    end_date = request.GET.get('end')
    
    if start_date and end_date:
        try:
            start = datetime.fromisoformat(start_date.replace('Z', '+00:00'))
            end = datetime.fromisoformat(end_date.replace('Z', '+00:00'))
            
            sessions = EnhancedStudySession.objects.filter(
                Q(organizer=request.user) | Q(participants=request.user),
                start_time__range=[start, end]
            ).distinct()
            
            events = []
            for session in sessions:
                events.append({
                    'id': session.id,
                    'title': session.title,
                    'start': session.start_time.isoformat(),
                    'end': session.end_time.isoformat(),
                    'color': '#667eea' if session.organizer == request.user else '#4facfe',
                    'url': f'/sessions/{session.id}/'
                })
            
            return JsonResponse(events, safe=False)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=400)
    
    return JsonResponse([], safe=False)


# ---------------------------------------
# Debug Views (Remove in production)
# ---------------------------------------
def debug_users(request):
    """Debug view to see all users - REMOVE IN PRODUCTION"""
    if not request.user.is_superuser:
        messages.error(request, "Access denied.")
        return redirect('studybuddy_app:index')
    
    users = User.objects.all()
    return render(request, 'studybuddy_app/debug_users.html', {'users': users})