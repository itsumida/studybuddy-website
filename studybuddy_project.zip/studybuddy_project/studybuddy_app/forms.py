from django import forms
from .models import Profile
from .models import Course
from datetime import time

class ProfileAddForm(forms.ModelForm):
    courses = forms.ModelMultipleChoiceField(
        queryset=Course.objects.all(),
        widget=forms.CheckboxSelectMultiple,
        required=False,
        help_text="Don't see your course? <a href='/sbuddy/course/add' target='_blank'>Add it here!</a>"
    )
    date = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}))

    time_choices = [
        (time(hour=h, minute=m).strftime('%H:%M'), time(hour=h, minute=m).strftime('%I:%M %p'))
        for h in range(8, 18) for m in (0, 30)
    ]
    time = forms.ChoiceField(choices=[('', 'Select a Time')] + time_choices)

    class Meta:
        model = Profile
        fields = ["first_name", "last_name", "email", "bio", "courses", "date", "time"]

        model = Profile
        fields = ["first_name", "last_name", "email", "bio", "courses"]

        courses = forms.ModelMultipleChoiceField(
        queryset=Course.objects.all(),
        widget=forms.CheckboxSelectMultiple)

class CourseAddForm(forms.ModelForm):
    class Meta:
        model = Course 
        fields = ["code", "name", "description"]  

