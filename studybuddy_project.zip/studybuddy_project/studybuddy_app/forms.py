from django import forms
from .models import Profile
from .models import Course

class ProfileAddForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = ["fname", "lname", "email", "bio", "availability", "courses", "study_methods"]

        courses = forms.ModelMultipleChoiceField(
        queryset=Course.objects.all(),
        widget=forms.CheckboxSelectMultiple)

class CourseAddForm(forms.ModelForm):
    class Meta:
        model = Course 
        fields = ["code", "name", "description"]       