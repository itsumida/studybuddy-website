from django.shortcuts import render, get_object_or_404, redirect
from django.urls import reverse
from .models import Profile
from .models import Course
from .forms import ProfileAddForm, CourseAddForm

def index(request):
    return render(request, "index.html")

def profile(request, pk):
    profile = get_object_or_404(Profile, pk=pk)
    courses = profile.courses.all()
    return render(request, "profile.html", {"profile": profile, "courses":courses})

def course(request, pk):
    course = get_object_or_404(Course, pk=pk)
    return render(request, "course.html", {"course": course})

def profile_add(request):
    if request.method == "POST":
        form = ProfileAddForm(request.POST)
        if form.is_valid():
            profile = form.save()  
            return redirect(reverse("profile", kwargs={"pk": profile.pk}))  
    else:
        form = ProfileAddForm()
    return render(request, "profile_add.html", {"form": form})

def course_add(request):
    if request.method=="POST":
        form = CourseAddForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("index")
    else:
        form = CourseAddForm()
    return render(request, "course_add.html", {"form": form})        
