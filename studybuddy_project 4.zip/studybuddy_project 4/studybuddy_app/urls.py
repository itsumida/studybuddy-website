from django.urls import path
from . import views
from django.contrib.auth.decorators import login_required

app_name = 'studybuddy_app'

urlpatterns = [
    # Home and Core
    path("", views.index, name="index"),
    
    # Authentication (Custom Views)
    path("accounts/signup/", views.signup, name="signup"),
    path("accounts/login/", views.user_login, name="login"),
    path("accounts/logout/", views.user_logout, name="logout"),
    path("about/", views.more_about, name="more_about"),
    
    # Profile Management
    path("profiles/", login_required(views.profile_list), name="profile_list"),
    path("profile/add/", login_required(views.profile_add), name="profile_add"),
    path("profile/<int:pk>/", login_required(views.user_profile), name="user_profile"), 
    path("profile/<int:pk>/welcome/", login_required(views.profile), name="profile"),
    path('find-buddies/', views.find_buddies, name='find_buddies'),
    path('profile/<int:pk>/edit/', views.profile_edit, name='profile_edit'),

    
    # Course Management
    path("courses/", views.course_list, name="course_list"),
    # path("course/add/", login_required(views.course_add), name="course_add"),
    # path("course/<int:pk>/", views.course_detail, name="course_detail"),
    
    # Messaging System
    path("messages/", login_required(views.inbox), name="inbox"),
    path("message/send/<int:receiver_id>/", login_required(views.send_message), name="send_message"),
    # path('add-session/', views.add_session, name='add_session'),

    
    # Review System
    path("review/<int:profile_id>/", login_required(views.leave_review), name="leave_review"),
    
    # Study Tools
    path("calendar/", login_required(views.study_calendar), name="study_calendar"),
    # path("matches/", login_required(views.find_matches), name="find_matches"),
    path("search/", views.search_buddies, name="search_buddies"),
    
    path('messages/reply/<int:sender_id>/', views.reply_message, name='reply_message'),
    path('messages/chat/<int:user_id>/', views.chat_thread, name='chat_thread'),


]

# Error handlers (uncomment when ready)
# handler404 = 'studybuddy_app.views.custom_404'
# handler500 = 'studybuddy_app.views.custom_500'